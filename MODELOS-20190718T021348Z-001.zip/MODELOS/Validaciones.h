int funcion_ValidarTelefono(char* str);
void validarTel(char* x);
int funcion_validarEmail(char* str);
void validarEmail(char* x);
int validarString(char* x);
int validarStringTam(char* x, int largo);
int validarEnteroTam(char* entero, int largo);
int validarEntero(char* entero);
float validarFloat(char* sueldo);
char validarSexo();
char validarSeguir();
//int compararFechas(eFecha fech, eFecha fecha);
void validarAlfaNum(char* x, int largo);
void ValidarPatente(char* x);
int validarEnteroFecha(char* entero, int corto, int largo);
int validarEnteroRango(char* entero, int corto, int largo);


